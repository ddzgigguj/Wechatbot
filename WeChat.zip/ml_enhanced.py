"""
Enhanced ML Predictor для MKX Strategy Bot v4.0
Онлайн-обучение, ансамбль моделей, feature engineering
"""

import json
import logging
import pickle
import os
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from collections import deque
import numpy as np

logger = logging.getLogger(__name__)

# Пробуем импортировать sklearn
try:
    from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
    from sklearn.neural_network import MLPClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split, cross_val_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn не установлен. ML функции ограничены.")

import config
from characters_db import get_character_type, get_character_elo, EXECUTORS, DONORS


@dataclass
class EnhancedMatchFeatures:
    """Расширенные признаки матча для ML"""
    # Базовые признаки
    executor_strength: float
    donor_weakness: float
    time_pattern_score: float
    recent_wave_factor: float
    odds_value: float
    confidence_score: float
    
    # Новые признаки v4.0
    elo_diff: float
    head_to_head: float
    momentum_p1: float
    momentum_p2: float
    time_of_day_factor: float
    day_of_week: int
    match_density: int
    market_confidence: float
    
    # Коэффициенты
    p1_odds: float
    p2_odds: float
    fatality_odds: float
    
    # Флаги
    is_golden_minute: bool
    is_dead_minute: bool
    wave_streak: int
    consecutive_losses: int


class OnlineMLModel:
    """
    Модель с онлайн-обучением (partial fit)
    Обновляется после каждого матча
    """
    
    def __init__(self, model_file: str = "online_ml_model.pkl"):
        self.model_file = model_file
        self.scaler = StandardScaler()
        self.is_trained = False
        self.training_count = 0
        self.accuracy_history = deque(maxlen=100)
        
        # Используем SGDClassifier для онлайн-обучения
        try:
            from sklearn.linear_model import SGDClassifier
            self.model = SGDClassifier(
                loss='log_loss',
                learning_rate='adaptive',
                eta0=0.01,
                max_iter=1000,
                tol=1e-3,
                random_state=42
            )
            self.online_capable = True
        except:
            self.model = None
            self.online_capable = False
        
        self._load_model()
    
    def _load_model(self):
        """Загружает модель"""
        if os.path.exists(self.model_file):
            try:
                with open(self.model_file, 'rb') as f:
                    data = pickle.load(f)
                    self.model = data['model']
                    self.scaler = data['scaler']
                    self.is_trained = data.get('is_trained', False)
                    self.training_count = data.get('training_count', 0)
                logger.info(f"Online ML модель загружена ({self.training_count} обучений)")
            except Exception as e:
                logger.error(f"Ошибка загрузки модели: {e}")
    
    def _save_model(self):
        """Сохраняет модель"""
        try:
            with open(self.model_file, 'wb') as f:
                pickle.dump({
                    'model': self.model,
                    'scaler': self.scaler,
                    'is_trained': self.is_trained,
                    'training_count': self.training_count
                }, f)
        except Exception as e:
            logger.error(f"Ошибка сохранения модели: {e}")
    
    def partial_fit(self, features: np.ndarray, result: int):
        """Частичное обучение на новых данных"""
        if not self.online_capable or self.model is None:
            return
        
        try:
            # Нормализация
            if not self.is_trained:
                X_scaled = self.scaler.fit_transform(features)
                self.model.partial_fit(X_scaled, [result], classes=[0, 1])
                self.is_trained = True
            else:
                X_scaled = self.scaler.transform(features)
                self.model.partial_fit(X_scaled, [result])
            
            self.training_count += 1
            
            # Сохраняем каждые 10 обучений
            if self.training_count % 10 == 0:
                self._save_model()
                logger.info(f"Online ML обучение #{self.training_count}")
                
        except Exception as e:
            logger.error(f"Ошибка онлайн-обучения: {e}")
    
    def predict(self, features: np.ndarray) -> Tuple[float, str]:
        """Предсказание"""
        if not self.is_trained or not self.online_capable:
            return 50.0, "UNKNOWN"
        
        try:
            X_scaled = self.scaler.transform(features)
            prob = self.model.predict_proba(X_scaled)[0]
            probability = prob[1] * 100
            
            if probability >= 70:
                rec = "STRONG"
            elif probability >= 50:
                rec = "MEDIUM"
            else:
                rec = "WEAK"
            
            return probability, rec
        except Exception as e:
            logger.error(f"Ошибка предсказания: {e}")
            return 50.0, "UNKNOWN"


class EnsemblePredictor:
    """
    Ансамбль моделей для повышения точности
    """
    
    def __init__(self):
        self.models = {}
        self.weights = {}
        self.scaler = StandardScaler()
        
        if SKLEARN_AVAILABLE:
            self._init_models()
    
    def _init_models(self):
        """Инициализирует модели ансамбля"""
        self.models = {
            'gradient_boosting': GradientBoostingClassifier(
                n_estimators=200,
                learning_rate=0.1,
                max_depth=4,
                random_state=42
            ),
            'random_forest': RandomForestClassifier(
                n_estimators=150,
                max_depth=6,
                random_state=42
            ),
            'neural_net': MLPClassifier(
                hidden_layer_sizes=(64, 32, 16),
                max_iter=1000,
                random_state=42,
                early_stopping=True
            )
        }
        
        # Веса моделей (будут адаптироваться)
        self.weights = {
            'gradient_boosting': 0.5,
            'random_forest': 0.3,
            'neural_net': 0.2
        }
        
        self.is_trained = False
    
    def train(self, X: np.ndarray, y: np.ndarray):
        """Обучает все модели"""
        if not SKLEARN_AVAILABLE:
            return
        
        try:
            # Разделение данных
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Нормализация
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Обучаем каждую модель
            scores = {}
            for name, model in self.models.items():
                logger.info(f"Обучение модели: {name}")
                model.fit(X_train_scaled, y_train)
                score = model.score(X_test_scaled, y_test)
                scores[name] = score
                logger.info(f"{name} accuracy: {score:.3f}")
            
            # Адаптируем веса на основе точности
            total_score = sum(scores.values())
            if total_score > 0:
                for name in self.weights:
                    self.weights[name] = scores[name] / total_score
            
            self.is_trained = True
            logger.info(f"Веса ансамбля: {self.weights}")
            
        except Exception as e:
            logger.error(f"Ошибка обучения ансамбля: {e}")
    
    def predict(self, features: np.ndarray) -> Tuple[float, str]:
        """Предсказание ансамбля"""
        if not self.is_trained or not SKLEARN_AVAILABLE:
            return 50.0, "UNKNOWN"
        
        try:
            X_scaled = self.scaler.transform(features)
            
            # Собираем предсказания всех моделей
            predictions = {}
            for name, model in self.models.items():
                if hasattr(model, 'predict_proba'):
                    prob = model.predict_proba(X_scaled)[0]
                    predictions[name] = prob[1]
            
            # Взвешенное среднее
            weighted_prob = sum(
                predictions.get(k, 0.5) * self.weights[k] 
                for k in self.weights
            )
            
            probability = weighted_prob * 100
            
            if probability >= 70:
                rec = "STRONG"
            elif probability >= 50:
                rec = "MEDIUM"
            else:
                rec = "WEAK"
            
            return probability, rec
            
        except Exception as e:
            logger.error(f"Ошибка предсказания ансамбля: {e}")
            return 50.0, "UNKNOWN"


class EnhancedMLPredictor:
    """
    Основной ML предиктор с онлайн-обучением и ансамблем
    """
    
    def __init__(self):
        self.online_model = OnlineMLModel()
        self.ensemble = EnsemblePredictor()
        self.use_ensemble = SKLEARN_AVAILABLE
        self.match_history = deque(maxlen=50)  # Для моментума
        
    # ИСПРАВЛЕНО: Добавлен метод is_golden_minute_range, который был импортирован из main
    def is_golden_minute_range(self, match_time: str, window: int = 2) -> Tuple[bool, int]:
        """
        Проверяет, находится ли время в золотой минуте (с окном ±window минут)
        
        Args:
            match_time: Время в формате "HH:MM"
            window: Окно в минутах
            
        Returns:
            (is_golden, minutes_diff)
        """
        try:
            from datetime import datetime
            hour, minute = map(int, match_time.split(':'))
            match_minutes = hour * 60 + minute
            
            for golden in config.GOLDEN_MINUTES:
                gh, gm = map(int, golden.split(':'))
                golden_minutes = gh * 60 + gm
                diff = abs(match_minutes - golden_minutes)
                
                if diff <= window:
                    return True, diff
            
            return False, 0
        except Exception:
            return False, 0
        
    def extract_features(self, match_data, analyzer_data: Dict) -> EnhancedMatchFeatures:
        """Извлекает расширенные признаки"""
        
        # Типы персонажей
        p1_type, p1_info = get_character_type(match_data.player1)
        p2_type, p2_info = get_character_type(match_data.player2)
        
        # ELO рейтинги
        p1_elo = get_character_elo(match_data.player1)
        p2_elo = get_character_elo(match_data.player2)
        elo_diff = p1_elo - p2_elo
        
        # Сила палача / слабость донора
        executor_strength = 0
        if p1_type == "EXECUTOR":
            executor_strength = p1_info.get('winrate', 50)
        
        donor_weakness = 0
        if p2_type == "DONOR":
            donor_weakness = p2_info.get('donor_rate', 50)
        
        # Head-to-head (заглушка - можно добавить из БД)
        head_to_head = 50.0
        
        # Моментум (последние матчи)
        momentum_p1 = self._calculate_momentum(match_data.player1)
        momentum_p2 = self._calculate_momentum(match_data.player2)
        
        # Временные факторы
        hour = match_data.timestamp.hour
        time_of_day_factor = self._get_time_factor(hour)
        day_of_week = match_data.timestamp.weekday()
        
        # Плотность матчей
        match_density = len([m for m in self.match_history 
                            if (datetime.now() - m).total_seconds() < 3600])
        
        # Уверенность рынка
        market_confidence = abs(match_data.p1_match_odds - match_data.p2_match_odds)
        
        # Волна бритья
        wave_streak = analyzer_data.get('wave_streak', 0)
        recent_wave_factor = min(wave_streak * 10, 50) if wave_streak >= 3 else 0
        
        # Коэффициенты
        # ИСПРАВЛЕНО: Используем правильное имя константы
        ideal_min, ideal_max = config.IDEAL_FATALITY_KF_RANGE
        odds_value = 0
        if ideal_min <= match_data.fatality_odds <= ideal_max:
            odds_value = 100
        elif match_data.fatality_odds >= config.MIN_FATALITY_KF:
            odds_value = 70
        
        # Временной паттерн
        match_time = match_data.timestamp.strftime("%H:%M")
        # ИСПРАВЛЕНО: Используем локальный метод вместо импорта
        is_golden, _ = self.is_golden_minute_range(match_time)
        time_pattern_score = 70 if is_golden else 50
        
        return EnhancedMatchFeatures(
            executor_strength=executor_strength,
            donor_weakness=donor_weakness,
            time_pattern_score=time_pattern_score,
            recent_wave_factor=recent_wave_factor,
            odds_value=odds_value,
            confidence_score=analyzer_data.get('confidence_score', 0),
            elo_diff=elo_diff,
            head_to_head=head_to_head,
            momentum_p1=momentum_p1,
            momentum_p2=momentum_p2,
            time_of_day_factor=time_of_day_factor,
            day_of_week=day_of_week,
            match_density=match_density,
            market_confidence=market_confidence,
            p1_odds=match_data.p1_match_odds,
            p2_odds=match_data.p2_match_odds,
            fatality_odds=match_data.fatality_odds,
            is_golden_minute=is_golden,
            is_dead_minute=match_time in config.DEAD_MINUTES,
            wave_streak=wave_streak,
            consecutive_losses=analyzer_data.get('consecutive_losses', 0)
        )
    
    def _calculate_momentum(self, player_name: str) -> float:
        """Рассчитывает моментум игрока (последние 5 матчей)"""
        # Заглушка - в реальности нужно брать из БД
        return 50.0
    
    def _get_time_factor(self, hour: int) -> float:
        """Фактор времени суток"""
        if 0 <= hour < 6:
            return 60  # Ночь - лучшее время
        elif 6 <= hour < 12:
            return 50  # Утро
        elif 12 <= hour < 18:
            return 45  # День - хуже
        else:
            return 55  # Вечер
    
    def features_to_array(self, features: EnhancedMatchFeatures) -> np.ndarray:
        """Конвертирует признаки в numpy массив"""
        return np.array([
            features.executor_strength,
            features.donor_weakness,
            features.time_pattern_score,
            features.recent_wave_factor,
            features.odds_value,
            features.confidence_score,
            features.elo_diff,
            features.head_to_head,
            features.momentum_p1,
            features.momentum_p2,
            features.time_of_day_factor,
            features.day_of_week,
            features.match_density,
            features.market_confidence,
            features.p1_odds,
            features.p2_odds,
            features.fatality_odds,
            1 if features.is_golden_minute else 0,
            1 if features.is_dead_minute else 0,
            features.wave_streak,
            features.consecutive_losses
        ]).reshape(1, -1)
    
    def predict(self, match_data, analyzer_data: Dict) -> Tuple[float, str, Dict]:
        """
        Делает предсказание используя ансамбль и онлайн-модель
        """
        features = self.extract_features(match_data, analyzer_data)
        features_array = self.features_to_array(features)
        
        # Предсказание ансамбля
        if self.use_ensemble and self.ensemble.is_trained:
            ensemble_prob, ensemble_rec = self.ensemble.predict(features_array)
            model_used = "ensemble"
        else:
            ensemble_prob, ensemble_rec = 50.0, "UNKNOWN"
            model_used = "none"
        
        # Предсказание онлайн-модели
        if self.online_model.is_trained:
            online_prob, online_rec = self.online_model.predict(features_array)
            # Комбинируем
            final_prob = (ensemble_prob * 0.6 + online_prob * 0.4)
            model_used = "combined"
        else:
            final_prob = ensemble_prob
        
        # Определяем рекомендацию
        if final_prob >= 70:
            recommendation = "STRONG"
        elif final_prob >= 50:
            recommendation = "MEDIUM"
        else:
            recommendation = "WEAK"
        
        details = {
            'model_used': model_used,
            'ensemble_prob': ensemble_prob,
            'online_prob': online_prob if self.online_model.is_trained else None,
            'features': {
                'executor_strength': features.executor_strength,
                'donor_weakness': features.donor_weakness,
                'elo_diff': features.elo_diff,
                'momentum_p1': features.momentum_p1,
                'momentum_p2': features.momentum_p2
            }
        }
        
        return final_prob, recommendation, details
    
    def record_result(self, match_data, analyzer_data: Dict, result: bool):
        """
        Записывает результат и обучает онлайн-модель
        """
        features = self.extract_features(match_data, analyzer_data)
        features_array = self.features_to_array(features)
        
        # Онлайн-обучение
        if config.ML_ONLINE_LEARNING:
            self.online_model.partial_fit(features_array, 1 if result else 0)
            logger.info(f"Online ML обучение: result={result}")
        
        # Сохраняем в историю
        self.match_history.append(datetime.now())
    
    def train_ensemble(self, training_data: List[Dict]):
        """Обучает ансамбль на исторических данных"""
        if not SKLEARN_AVAILABLE or len(training_data) < config.ML_MIN_SAMPLES:
            logger.warning(f"Недостаточно данных для обучения ансамбля: {len(training_data)}/{config.ML_MIN_SAMPLES}")
            return
        
        try:
            X = []
            y = []
            
            for record in training_data:
                features = json.loads(record['features'])
                X.append([
                    features.get('executor_strength', 0),
                    features.get('donor_weakness', 0),
                    features.get('time_pattern_score', 0),
                    features.get('recent_wave_factor', 0),
                    features.get('odds_value', 0),
                    features.get('confidence_score', 0),
                    features.get('elo_diff', 0),
                    features.get('head_to_head', 50),
                    features.get('momentum_p1', 50),
                    features.get('momentum_p2', 50),
                    features.get('time_of_day_factor', 50),
                    features.get('day_of_week', 0),
                    features.get('match_density', 0),
                    features.get('market_confidence', 0),
                    features.get('p1_odds', 0),
                    features.get('p2_odds', 0),
                    features.get('fatality_odds', 0),
                    features.get('is_golden_minute', 0),
                    features.get('is_dead_minute', 0),
                    features.get('wave_streak', 0),
                    features.get('consecutive_losses', 0)
                ])
                y.append(record['result'])
            
            X = np.array(X)
            y = np.array(y)
            
            logger.info(f"Обучение ансамбля на {len(X)} записях...")
            self.ensemble.train(X, y)
            
        except Exception as e:
            logger.error(f"Ошибка обучения ансамбля: {e}")


# Глобальный экземпляр
enhanced_ml = EnhancedMLPredictor()
