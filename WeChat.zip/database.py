"""
Async SQLite Database для MKX Strategy Bot v4.0
Улучшенная версия с async/await и оптимизациями
"""

import json
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import asyncio
import aiosqlite

import config

logger = logging.getLogger(__name__)


@dataclass
class MatchResult:
    """Результат матча"""
    match_id: str
    player1: str
    player2: str
    total_rounds: int
    fatality_round: Optional[int]
    brutality_round: Optional[int]
    no_finish_count: int
    result: str
    timestamp: datetime


class AsyncMKXDatabase:
    """
    Асинхронная база данных SQLite
    """
    
    def __init__(self, db_file: str = config.DB_FILE):
        self.db_file = db_file
        self._lock = asyncio.Lock()
    
    async def init(self):
        """Инициализирует базу данных"""
        async with aiosqlite.connect(self.db_file) as db:
            await self._create_tables(db)
    
    async def _create_tables(self, db: aiosqlite.Connection):
        """Создает таблицы"""
        # Таблица матчей
        await db.execute('''
            CREATE TABLE IF NOT EXISTS matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT UNIQUE NOT NULL,
                player1 TEXT NOT NULL,
                player2 TEXT NOT NULL,
                league TEXT,
                match_time TIMESTAMP,
                p1_match_odds REAL,
                p2_match_odds REAL,
                fatality_odds REAL,
                brutality_odds REAL,
                no_finish_odds REAL,
                total_rounds INTEGER DEFAULT 0,
                fatality_round INTEGER,
                brutality_round INTEGER,
                no_finish_count INTEGER DEFAULT 0,
                result TEXT DEFAULT 'pending',
                confidence_score INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица раундов
        await db.execute('''
            CREATE TABLE IF NOT EXISTS rounds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                round_num INTEGER NOT NULL,
                winner TEXT NOT NULL,
                finish_type TEXT NOT NULL,
                time_seconds INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(match_id, round_num)
            )
        ''')
        
        # Таблица ставок
        await db.execute('''
            CREATE TABLE IF NOT EXISTS bets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                bet_type TEXT NOT NULL,
                predicted_round INTEGER,
                amount REAL NOT NULL,
                odds REAL NOT NULL,
                result TEXT DEFAULT 'pending',
                won_in_round INTEGER,
                profit REAL DEFAULT 0,
                dogon_step INTEGER DEFAULT 0,
                kelly_fraction REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP
            )
        ''')
        
        # Таблица статистики по персонажам
        await db.execute('''
            CREATE TABLE IF NOT EXISTS character_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                character_name TEXT UNIQUE NOT NULL,
                total_matches INTEGER DEFAULT 0,
                wins INTEGER DEFAULT 0,
                fatalities INTEGER DEFAULT 0,
                brutalities INTEGER DEFAULT 0,
                no_finishes INTEGER DEFAULT 0,
                avg_rounds REAL DEFAULT 0,
                winrate REAL DEFAULT 0,
                fatality_rate REAL DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица для ML данных
        await db.execute('''
            CREATE TABLE IF NOT EXISTS ml_training_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                features TEXT NOT NULL,
                result INTEGER NOT NULL,
                confidence REAL,
                predicted_prob REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица статистики по времени
        await db.execute('''
            CREATE TABLE IF NOT EXISTS time_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hour INTEGER NOT NULL,
                minute INTEGER NOT NULL,
                total_matches INTEGER DEFAULT 0,
                fatalities INTEGER DEFAULT 0,
                brutalities INTEGER DEFAULT 0,
                no_finishes INTEGER DEFAULT 0,
                winrate REAL DEFAULT 0,
                UNIQUE(hour, minute)
            )
        ''')
        
        # Индексы
        await db.execute('CREATE INDEX IF NOT EXISTS idx_bets_match_id ON bets(match_id)')
        await db.execute('CREATE INDEX IF NOT EXISTS idx_bets_result ON bets(result)')
        await db.execute('CREATE INDEX IF NOT EXISTS idx_matches_time ON matches(match_time)')
        
        await db.commit()
        logger.info("База данных инициализирована")
    
    # === Методы для матчей ===
    
    async def add_match(self, match_data) -> bool:
        """Добавляет матч"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO matches 
                    (match_id, player1, player2, league, match_time, 
                     p1_match_odds, p2_match_odds, fatality_odds, 
                     brutality_odds, no_finish_odds, confidence_score)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    match_data.match_id,
                    match_data.player1,
                    match_data.player2,
                    match_data.league,
                    match_data.timestamp,
                    match_data.p1_match_odds,
                    match_data.p2_match_odds,
                    match_data.fatality_odds,
                    match_data.brutality_odds,
                    match_data.no_finish_odds,
                    getattr(match_data, 'confidence_score', 0)
                ))
                await db.commit()
                return True
        except Exception as e:
            logger.error(f"Ошибка добавления матча: {e}")
            return False
    
    async def update_match_result(self, match_id: str, result: str, 
                                   total_rounds: int = 0,
                                   fatality_round: Optional[int] = None,
                                   brutality_round: Optional[int] = None,
                                   no_finish_count: int = 0):
        """Обновляет результат матча"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                await db.execute('''
                    UPDATE matches 
                    SET result = ?, total_rounds = ?, 
                        fatality_round = ?, brutality_round = ?, no_finish_count = ?
                    WHERE match_id = ?
                ''', (result, total_rounds, fatality_round, brutality_round, 
                      no_finish_count, match_id))
                await db.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления результата: {e}")
    
    # === Методы для ставок ===
    
    async def add_bet(self, match_id: str, bet_type: str, predicted_round: Optional[int],
                      amount: float, odds: float, dogon_step: int = 0,
                      kelly_fraction: Optional[float] = None) -> Optional[int]:
        """Добавляет ставку"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                cursor = await db.execute('''
                    INSERT INTO bets (match_id, bet_type, predicted_round, amount, odds, dogon_step, kelly_fraction)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (match_id, bet_type, predicted_round, amount, odds, dogon_step, kelly_fraction))
                await db.commit()
                return cursor.lastrowid
        except Exception as e:
            logger.error(f"Ошибка добавления ставки: {e}")
            return None
    
    async def update_bet_result(self, bet_id: int, result: str, 
                                 won_in_round: Optional[int] = None,
                                 profit: float = 0):
        """Обновляет результат ставки"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                await db.execute('''
                    UPDATE bets 
                    SET result = ?, won_in_round = ?, profit = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (result, won_in_round, profit, bet_id))
                await db.commit()
        except Exception as e:
            logger.error(f"Ошибка обновления ставки: {e}")
    
    async def get_bet_stats_async(self, days: int = 1) -> Dict:
        """Получает статистику ставок (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN result = 'won' THEN 1 ELSE 0 END) as wins,
                        SUM(CASE WHEN result = 'lost' THEN 1 ELSE 0 END) as losses,
                        SUM(CASE WHEN result = 'won' THEN profit ELSE 0 END) as total_profit,
                        SUM(CASE WHEN result = 'lost' THEN -amount ELSE 0 END) as total_loss
                    FROM bets
                    WHERE created_at >= datetime('now', ?)
                ''', (f'-{days} days',))
                
                row = await cursor.fetchone()
                if row:
                    total = row['total'] or 0
                    wins = row['wins'] or 0
                    losses = row['losses'] or 0
                    profit = (row['total_profit'] or 0) + (row['total_loss'] or 0)
                    
                    return {
                        'total': total,
                        'wins': wins,
                        'losses': losses,
                        'net_profit': profit,
                        'winrate': (wins / (wins + losses) * 100) if (wins + losses) > 0 else 0,
                        'roi': (profit / (total * 1000) * 100) if total > 0 else 0  # Примерный ROI
                    }
                return {'total': 0, 'wins': 0, 'losses': 0, 'net_profit': 0, 'winrate': 0, 'roi': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {'total': 0, 'wins': 0, 'losses': 0, 'net_profit': 0, 'winrate': 0, 'roi': 0}
    
    # === ML методы ===
    
    async def add_ml_training_data(self, match_id: str, features: Dict, result: int, 
                                    confidence: float, predicted_prob: float):
        """Добавляет данные для ML"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                await db.execute('''
                    INSERT INTO ml_training_data (match_id, features, result, confidence, predicted_prob)
                    VALUES (?, ?, ?, ?, ?)
                ''', (match_id, json.dumps(features), result, confidence, predicted_prob))
                await db.commit()
        except Exception as e:
            logger.error(f"Ошибка добавления ML данных: {e}")
    
    async def get_ml_training_data_async(self, limit: int = 1000) -> List[Dict]:
        """Получает данные для обучения ML (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute('''
                    SELECT * FROM ml_training_data
                    ORDER BY created_at DESC
                    LIMIT ?
                ''', (limit,))
                
                rows = await cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Ошибка получения ML данных: {e}")
            return []
    
    async def get_ml_accuracy_async(self, days: int = 1) -> float:
        """Получает точность ML (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                cursor = await db.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN 
                            (predicted_prob >= 50 AND result = 1) OR 
                            (predicted_prob < 50 AND result = 0) 
                        THEN 1 ELSE 0 END) as correct
                    FROM ml_training_data
                    WHERE created_at >= datetime('now', ?)
                ''', (f'-{days} days',))
                
                row = await cursor.fetchone()
                if row and row[0] > 0:
                    return (row[1] / row[0]) * 100
                return 50.0
        except Exception as e:
            logger.error(f"Ошибка получения точности ML: {e}")
            return 50.0
    
    # === Статистика по времени ===
    
    async def get_time_pattern_stats_async(self, hour: int, minute: int) -> Dict:
        """Получает статистику по времени (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                time_pattern = f"{hour:02d}:{minute:02d}"
                
                cursor = await db.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN fatality_round IS NOT NULL THEN 1 ELSE 0 END) as fatalities,
                        SUM(CASE WHEN brutality_round IS NOT NULL THEN 1 ELSE 0 END) as brutalities
                    FROM matches
                    WHERE strftime('%H:%M', match_time) = ?
                    AND result != 'pending'
                ''', (time_pattern,))
                
                row = await cursor.fetchone()
                if row and row['total'] > 0:
                    total = row['total']
                    return {
                        'total_matches': total,
                        'fatality_rate': row['fatalities'] / total * 100,
                        'brutality_rate': row['brutalities'] / total * 100,
                        'any_finish_rate': (row['fatalities'] + row['brutalities']) / total * 100
                    }
                return {'total_matches': 0, 'fatality_rate': 0, 'brutality_rate': 0, 'any_finish_rate': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики по времени: {e}")
            return {'total_matches': 0, 'fatality_rate': 0, 'brutality_rate': 0, 'any_finish_rate': 0}
    
    async def get_hourly_stats_async(self, days: int = 1) -> List[Dict]:
        """Получает почасовую статистику (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute('''
                    SELECT 
                        strftime('%H', match_time) as hour,
                        COUNT(*) as total,
                        SUM(CASE WHEN result = 'won' THEN 1 ELSE 0 END) as wins
                    FROM matches
                    WHERE match_time >= datetime('now', ?)
                    GROUP BY hour
                    ORDER BY hour
                ''', (f'-{days} days',))
                
                rows = await cursor.fetchall()
                result = []
                for row in rows:
                    total = row['total'] or 0
                    wins = row['wins'] or 0
                    result.append({
                        'hour': int(row['hour']),
                        'total': total,
                        'wins': wins,
                        'winrate': (wins / total * 100) if total > 0 else 0
                    })
                return result
        except Exception as e:
            logger.error(f"Ошибка получения почасовой статистики: {e}")
            return []
    
    # === Статистика по персонажам ===
    
    async def get_character_stats_async(self, character_name: str) -> Optional[Dict]:
        """Получает статистику персонажа (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute('''
                    SELECT * FROM character_stats
                    WHERE character_name = ?
                ''', (character_name,))
                
                row = await cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Ошибка получения статистики персонажа: {e}")
            return None
    
    async def get_top_characters_async(self, limit: int = 10) -> List[Dict]:
        """Получает топ персонажей (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute('''
                    SELECT * FROM character_stats
                    ORDER BY total_matches DESC
                    LIMIT ?
                ''', (limit,))
                
                rows = await cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Ошибка получения топ персонажей: {e}")
            return []
    
    async def get_combo_stats_async(self, p1: str, p2: str) -> Dict:
        """Получает статистику комбинации (async)"""
        try:
            async with aiosqlite.connect(self.db_file) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute('''
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN fatality_round IS NOT NULL THEN 1 ELSE 0 END) as fatalities,
                        AVG(fatality_round) as avg_fatality_round
                    FROM matches
                    WHERE ((player1 = ? AND player2 = ?) OR (player1 = ? AND player2 = ?))
                    AND result != 'pending'
                ''', (p1, p2, p2, p1))
                
                row = await cursor.fetchone()
                if row and row['total'] > 0:
                    total = row['total']
                    return {
                        'total_matches': total,
                        'fatality_rate': row['fatalities'] / total * 100,
                        'avg_fatality_round': row['avg_fatality_round'] or 0
                    }
                return {'total_matches': 0, 'fatality_rate': 0, 'avg_fatality_round': 0}
        except Exception as e:
            logger.error(f"Ошибка получения статистики комбо: {e}")
            return {'total_matches': 0, 'fatality_rate': 0, 'avg_fatality_round': 0}


# Глобальный экземпляр
async_db = AsyncMKXDatabase()
