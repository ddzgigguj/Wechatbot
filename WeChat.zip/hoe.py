# Telegram API credentials
# Получить на https://my.telegram.org/apps
TELEGRAM_API_ID=21427577
TELEGRAM_API_HASH=db6682b9135f71c82905a59a34fd78f2
PHONE_NUMBER=+996505121208

# Bot Token от @BotFather
BOT_TOKEN=7894008761:AAE3udyV5NEKgoN6bHYMonn6TjJ7LfZclso

# ID канала для мониторинга (без @)
SOURCE_CHANNEL=statamk10

# ID группы для отправки анализа (начинается с -100)
TARGET_GROUP_ID=-1003750986907

# Настройки банкролла
INITIAL_BANKROLL=10000
MAX_DAILY_LOSS_PERCENT=20
MAX_BET_PERCENT=10

# Опционально: ID администратора для уведомлений
ADMIN_USER_ID=1113664783

# === KELLY CRITERION SETTINGS ===
KELLY_FRACTION=0.25
MIN_KELLY_BET=500
MAX_KELLY_BET=5000

# === REDIS CONFIG (опционально) ===
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
# REDIS_PASSWORD=
